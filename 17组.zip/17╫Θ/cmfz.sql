/*==============================================================*/
/* DBMS name:      Sybase SQL Anywhere 10                       */
/* Created on:     2017/6/11 22:09:05                           */
/*==============================================================*/


if exists(select 1 from sys.sysforeignkey where role='FK_CM_CHAPT_REFERENCE_CM_ALBUM') then
    alter table cm_chapter
       delete foreign key FK_CM_CHAPT_REFERENCE_CM_ALBUM
end if;

if exists(select 1 from sys.sysforeignkey where role='FK_CM_CITY_REFERENCE_CM_PROVI') then
    alter table cm_city
       delete foreign key FK_CM_CITY_REFERENCE_CM_PROVI
end if;

if exists(select 1 from sys.sysforeignkey where role='FK_CM_ESSAY_REFERENCE_CM_GURU') then
    alter table cm_essay
       delete foreign key FK_CM_ESSAY_REFERENCE_CM_GURU
end if;

if exists(select 1 from sys.sysforeignkey where role='FK_CM_USER_REFERENCE_CM_CITY') then
    alter table cm_user
       delete foreign key FK_CM_USER_REFERENCE_CM_CITY
end if;

if exists(select 1 from sys.sysforeignkey where role='FK_CM_USER_REFERENCE_CM_GURU') then
    alter table cm_user
       delete foreign key FK_CM_USER_REFERENCE_CM_GURU
end if;

if exists(select 1 from sys.sysforeignkey where role='FK_CM_USER_�û����ʡ�����_CM_PROVI') then
    alter table cm_user
       delete foreign key FK_CM_USER_�û����ʡ�����_CM_PROVI
end if;

if exists(select 1 from sys.sysforeignkey where role='FK_CM_WORK_REFERENCE_CM_USER') then
    alter table cm_work
       delete foreign key FK_CM_WORK_REFERENCE_CM_USER
end if;

if exists(
   select 1 from sys.systable 
   where table_name='cm_admin'
     and table_type in ('BASE', 'GBL TEMP')
) then
    drop table cm_admin
end if;

if exists(
   select 1 from sys.systable 
   where table_name='cm_album'
     and table_type in ('BASE', 'GBL TEMP')
) then
    drop table cm_album
end if;

if exists(
   select 1 from sys.systable 
   where table_name='cm_banner'
     and table_type in ('BASE', 'GBL TEMP')
) then
    drop table cm_banner
end if;

if exists(
   select 1 from sys.systable 
   where table_name='cm_chapter'
     and table_type in ('BASE', 'GBL TEMP')
) then
    drop table cm_chapter
end if;

if exists(
   select 1 from sys.systable 
   where table_name='cm_city'
     and table_type in ('BASE', 'GBL TEMP')
) then
    drop table cm_city
end if;

if exists(
   select 1 from sys.systable 
   where table_name='cm_counter'
     and table_type in ('BASE', 'GBL TEMP')
) then
    drop table cm_counter
end if;

if exists(
   select 1 from sys.systable 
   where table_name='cm_essay'
     and table_type in ('BASE', 'GBL TEMP')
) then
    drop table cm_essay
end if;

if exists(
   select 1 from sys.systable 
   where table_name='cm_guru'
     and table_type in ('BASE', 'GBL TEMP')
) then
    drop table cm_guru
end if;

if exists(
   select 1 from sys.systable 
   where table_name='cm_menu'
     and table_type in ('BASE', 'GBL TEMP')
) then
    drop table cm_menu
end if;

if exists(
   select 1 from sys.systable 
   where table_name='cm_province'
     and table_type in ('BASE', 'GBL TEMP')
) then
    drop table cm_province
end if;

if exists(
   select 1 from sys.systable 
   where table_name='cm_user'
     and table_type in ('BASE', 'GBL TEMP')
) then
    drop table cm_user
end if;

if exists(
   select 1 from sys.systable 
   where table_name='cm_work'
     and table_type in ('BASE', 'GBL TEMP')
) then
    drop table cm_work
end if;

/*==============================================================*/
/* Table: cm_admin                                              */
/*==============================================================*/
create table cm_admin 
(
   id                   varchar(40)                    not null,
   username             varchar(40),
   password             varchar(40),
   salt                 varchar(10),
   constraint PK_CM_ADMIN primary key clustered (id)
);

/*==============================================================*/
/* Table: cm_album                                              */
/*==============================================================*/
create table cm_album 
(
   id                   varchar(40)                    not null,
   thumbnail            varchar(40),
   title                varchar(40),
   score                double,
   author               varcahr(40),
   broadcast            varchar(40),
   createDate           date,
   brief                varchar(1000),
   constraint PK_CM_ALBUM primary key clustered (id)
);

/*==============================================================*/
/* Table: cm_banner                                             */
/*==============================================================*/
create table cm_banner 
(
   id                   varchar(40)                    not null,
   "desc"               varchar(40),
   thumbnail            varchar(200),
   type                 integer(4),
   constraint PK_CM_BANNER primary key clustered (id)
);

/*==============================================================*/
/* Table: cm_chapter                                            */
/*==============================================================*/
create table cm_chapter 
(
   id                   varchar(40)                    not null,
   title                varchar(40),
   url                  varchar(200),
   size                 varchar(20),
   pid                  varchar(40),
   duration             varchar(40),
   constraint PK_CM_CHAPTER primary key clustered (id)
);

/*==============================================================*/
/* Table: cm_city                                               */
/*==============================================================*/
create table cm_city 
(
   id                   varchar(40)                    not null,
   name                 varchar(40),
   pid                  varchar(40),
   constraint PK_CM_CITY primary key clustered (id)
);

/*==============================================================*/
/* Table: cm_counter                                            */
/*==============================================================*/
create table cm_counter 
(
   id                   varchar(40)                    not null,
   ����                   varchar(40),
   count                varchar(10),
   wid                  varchar(40),
   constraint PK_CM_COUNTER primary key clustered (id)
);

/*==============================================================*/
/* Table: cm_essay                                              */
/*==============================================================*/
create table cm_essay 
(
   id                   varchar(40)                    not null,
   title                varchar(40),
   flag                 varchar(40),
   pubDate              date,
   tid                  varchar(40),
   link                 varchar(40),
   constraint PK_CM_ESSAY primary key clustered (id)
);

/*==============================================================*/
/* Table: cm_guru                                               */
/*==============================================================*/
create table cm_guru 
(
   id                   varchar(40)                    not null,
   name                 varchar(40),
   head                 varchar(100),
   constraint PK_CM_GURU primary key clustered (id)
);

/*==============================================================*/
/* Table: cm_menu                                               */
/*==============================================================*/
create table cm_menu 
(
   id                   varchar(40)                    not null,
   ����                   varchar(40),
   level                int,
   mid                  varchar(40),
   constraint PK_CM_MENU primary key clustered (id)
);

/*==============================================================*/
/* Table: cm_province                                           */
/*==============================================================*/
create table cm_province 
(
   id                   varchar(40)                    not null,
   pname                varchar(40),
   constraint PK_CM_PROVINCE primary key clustered (id)
);

/*==============================================================*/
/* Table: cm_user                                               */
/*==============================================================*/
create table cm_user 
(
   id                   varchar(40)                    not null,
   nickname             varchar(80),
   farmington           varchar(80),
   gender               varchar(10),
   description          varchar(200),
   phone                varchar(20),
   salt                 varchar(10),
   pwd                  varchar(40),
   photo                varchar(200),
   tid                  varchar(40),
   province             varchar(40),
   city                 varchar(40),
   constraint PK_CM_USER primary key clustered (id)
);

/*==============================================================*/
/* Table: cm_work                                               */
/*==============================================================*/
create table cm_work 
(
   id                   varchar(40)                    not null,
   category             varchar(40),
   uid                  varchar(40),
   createDate           date,
   constraint PK_CM_WORK primary key clustered (id)
);

